// let button = document.getElementById("btn");
// button.disabled = true;
// function validate() {
//   button.disabled = true;
//   let name = document.getElementById('name1').value;
//   let email = document.getElementById('email1').value;
//   let pattern = /^[A-Za-z._]{3,}@[A_Za-z]{3,}[.]{1}[A-Za-z]{2,6}$/;
//   let phone = document.getElementById("phone1").value;
//   let date = document.getElementById("date1").value;
//   if (name == "" || email == "" || phone == "" || date == "") {
//     button.disabled = true;
//   }
//   else if (phone.length<10 ||phone.length > 10) {
//     button.disabled = true;
//   }
//    else if (!email.match(pattern)) {
//       button.disabled = true;
//   }
//     else {
//       button.disabled = false;
//   }
//   alert('Sucess!');
// }


function validate(){

    if( document.myForm.name1.value == "" ) {
        alert( "Please provide your name!" );
        // document.myForm.name1.focus() ;
        // return false;
     }

     if(document.myForm.email1.value==""){
        alert("Please Enter you email!");
        document.myForm.email1.focus();
        return false;
     }

     if(document.myForm.phone1.value==""){
        alert("Please enter your phone number!");
        document.myForm.phone1.focus();
        return false;
     }

     if(document.myForm.date1.value==""){
        alert("Please select Date!");
        document.myForm.date1.focus();
        return false;
     }



}